package com.solar_energy.solar_generation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SolarGenerationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SolarGenerationApplication.class, args);
	}

}
