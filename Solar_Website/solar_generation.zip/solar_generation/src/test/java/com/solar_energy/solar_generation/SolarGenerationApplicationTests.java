package com.solar_energy.solar_generation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SolarGenerationApplicationTests {

	@Test
	void contextLoads() {
	}

}
